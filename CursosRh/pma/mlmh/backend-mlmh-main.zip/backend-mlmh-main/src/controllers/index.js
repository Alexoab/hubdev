module.exports.authController = require('./auth.controller');
module.exports.userController = require('./user.controller');
module.exports.registerController = require('./register.controller');
module.exports.recursoController = require('./recurso.controller');
module.exports.documentoRecursoController = require('./documentoRecurso.controller');
module.exports.inputDocumentController = require('./inputDocument.controller');
module.exports.analiseDocumentoController = require('./analiseDocumento.controller');
