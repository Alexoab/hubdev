const { version } = require('../../package.json');
const config = require('../config/config');

const swaggerDef = {
  openapi: '3.0.0',
  info: {
    title: 'Meu lote minha história API documentation',
    version,
    license: {
      name: 'MIT',
      url: 'https://github.com/adrianobarbosa1/backend-mlmh',
    },
  },
  servers: [
    {
      url: `http://localhost:${config.port}/v1`,
    },
  ],
};

module.exports = swaggerDef;
